package com.android.handstudio.gallery.vo

/**
 * Created by woong on 2015. 10. 20..
 */
class PhotoVO(var imgPath: String, var isSelected: Boolean)